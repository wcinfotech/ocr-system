/** Centralized TanStack Query keys to keep cache invalidation consistent. */
import type { ListParams } from "@/types";

export const queryKeys = {
  dashboard: {
    stats: ["dashboard", "stats"] as const,
    charts: ["dashboard", "charts"] as const,
    recentUsers: ["dashboard", "recent-users"] as const,
    recentBills: ["dashboard", "recent-bills"] as const,
  },
  users: {
    all: ["users"] as const,
    list: (p: ListParams) => ["users", "list", p] as const,
    detail: (id: string) => ["users", "detail", id] as const,
  },
  plans: {
    all: ["plans"] as const,
    list: (p: ListParams) => ["plans", "list", p] as const,
  },
  subscriptions: {
    all: ["subscriptions"] as const,
    list: (p: ListParams) => ["subscriptions", "list", p] as const,
  },
  bills: {
    all: ["bills"] as const,
    list: (p: ListParams) => ["bills", "list", p] as const,
  },
} as const;
