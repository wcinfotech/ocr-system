import axios, {
  type AxiosError,
  type AxiosInstance,
  type InternalAxiosRequestConfig,
} from "axios";
import { env } from "@/config/env";

/**
 * Single configured Axios instance for the whole app.
 * - Injects JWT access token from storage.
 * - Normalizes errors into a consistent shape.
 * - Handles 401 by clearing session (refresh hook can be added later).
 * NEVER import axios directly in components — always go through the service layer.
 */

export interface ApiError {
  status: number;
  message: string;
  details?: unknown;
}

const getToken = () =>
  typeof window === "undefined" ? null : window.localStorage.getItem(env.TOKEN_KEY);

export const apiClient: AxiosInstance = axios.create({
  baseURL: env.API_BASE_URL || "/api",
  timeout: env.API_TIMEOUT,
  headers: { "Content-Type": "application/json" },
});

apiClient.interceptors.request.use((config: InternalAxiosRequestConfig) => {
  const token = getToken();
  if (token) config.headers.set?.("Authorization", `Bearer ${token}`);
  return config;
});

apiClient.interceptors.response.use(
  (response) => response,
  (error: AxiosError<{ message?: string }>) => {
    const status = error.response?.status ?? 0;
    const message =
      error.response?.data?.message ||
      error.message ||
      "Something went wrong. Please try again.";

    if (status === 401 && typeof window !== "undefined") {
      // Session expired / invalid — clear and let route guards redirect.
      window.localStorage.removeItem(env.TOKEN_KEY);
      window.localStorage.removeItem(env.USER_KEY);
      window.dispatchEvent(new CustomEvent("admin:unauthorized"));
    }

    const apiError: ApiError = { status, message, details: error.response?.data };
    return Promise.reject(apiError);
  },
);

export const isApiError = (e: unknown): e is ApiError =>
  typeof e === "object" && e !== null && "status" in e && "message" in e;
