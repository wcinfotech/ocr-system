import { createFileRoute } from "@tanstack/react-router";
import Icon from "@mui/icons-material/SupportAgentOutlined";
import { ModulePlaceholder } from "@/components/common/ModulePlaceholder";

export const Route = createFileRoute("/_admin/support")({
  head: () => ({ meta: [{ title: "Support Tickets — Admin Panel" }] }),
  component: () => (
    <ModulePlaceholder
      title="Support Tickets"
      subtitle="Open, pending and resolved tickets with replies."
      icon={Icon}
    />
  ),
});
