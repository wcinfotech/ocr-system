import { createFileRoute } from "@tanstack/react-router";
import Icon from "@mui/icons-material/BadgeOutlined";
import { ModulePlaceholder } from "@/components/common/ModulePlaceholder";

export const Route = createFileRoute("/_admin/roles")({
  head: () => ({ meta: [{ title: "Roles — Admin Panel" }] }),
  component: () => (
    <ModulePlaceholder
      title="Roles"
      subtitle="Define roles and assign permissions."
      icon={Icon}
    />
  ),
});
