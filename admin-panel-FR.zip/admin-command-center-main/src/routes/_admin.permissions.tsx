import { createFileRoute } from "@tanstack/react-router";
import Icon from "@mui/icons-material/KeyOutlined";
import { ModulePlaceholder } from "@/components/common/ModulePlaceholder";

export const Route = createFileRoute("/_admin/permissions")({
  head: () => ({ meta: [{ title: "Permissions — Admin Panel" }] }),
  component: () => (
    <ModulePlaceholder
      title="Permissions"
      subtitle="Manage the permission catalog used across the app."
      icon={Icon}
    />
  ),
});
