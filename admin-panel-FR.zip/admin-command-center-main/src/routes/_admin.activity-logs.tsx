import { createFileRoute } from "@tanstack/react-router";
import Icon from "@mui/icons-material/HistoryOutlined";
import { ModulePlaceholder } from "@/components/common/ModulePlaceholder";

export const Route = createFileRoute("/_admin/activity-logs")({
  head: () => ({ meta: [{ title: "Activity Logs — Admin Panel" }] }),
  component: () => (
    <ModulePlaceholder
      title="Activity Logs"
      subtitle="Timeline of user, action, IP, browser and time."
      icon={Icon}
    />
  ),
});
