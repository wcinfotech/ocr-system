import { createFileRoute } from "@tanstack/react-router";
import Icon from "@mui/icons-material/FactCheckOutlined";
import { ModulePlaceholder } from "@/components/common/ModulePlaceholder";

export const Route = createFileRoute("/_admin/audit-logs")({
  head: () => ({ meta: [{ title: "Audit Logs — Admin Panel" }] }),
  component: () => (
    <ModulePlaceholder
      title="Audit Logs"
      subtitle="Old vs new values, changed by, module and action."
      icon={Icon}
    />
  ),
});
