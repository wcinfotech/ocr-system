import { createFileRoute } from "@tanstack/react-router";
import Icon from "@mui/icons-material/AdminPanelSettingsOutlined";
import { ModulePlaceholder } from "@/components/common/ModulePlaceholder";

export const Route = createFileRoute("/_admin/admins")({
  head: () => ({ meta: [{ title: "Admins — Admin Panel" }] }),
  component: () => (
    <ModulePlaceholder
      title="Admins"
      subtitle="Create admins and assign roles and permissions."
      icon={Icon}
    />
  ),
});
